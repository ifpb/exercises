class Matrix
  def add(a, b)
    #TODO
  end

  def multiply(a, b)
    #TODO
  end
end

