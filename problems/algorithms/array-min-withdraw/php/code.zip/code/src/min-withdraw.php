<?php

function withdraw($number)
{
  // TODO
}
