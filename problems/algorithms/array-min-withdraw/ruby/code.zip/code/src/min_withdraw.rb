def withdraw(value)
  # TODO
end
