function sum(array) {
  // TODO
}

function product(array) {
  // TODO
}

function sumOdds(array) {
  // TODO
}

export { sum, product, sumOdds };
