<?php

function sum($array)
{
  // TODO
}

function product($array)
{
  // TODO
}

function sumOdds($array)
{
  // TODO
}
