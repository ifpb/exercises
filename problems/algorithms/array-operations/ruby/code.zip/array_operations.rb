def sum(array)
  # TODO
end

def product(array)
  # TODO
end

def sumOdds(array)
  # TODO
end
