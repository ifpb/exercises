function primeFactors(number) {
  // TODO
}

export { primeFactors };
