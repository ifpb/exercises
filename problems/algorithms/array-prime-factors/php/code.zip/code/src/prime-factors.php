<?php

function primeFactors($number)
{
  // TODO
}
