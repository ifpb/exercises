def prime_factors(number)
  #  TODO
end
