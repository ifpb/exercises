import { isPrime } from '../../../function/prime/code/prime.js';

/**
 * begin: 1..n
 * end: 1..n, end > begin
 */
function primes(begin, end) {
  // TODO
}

export { primes };
