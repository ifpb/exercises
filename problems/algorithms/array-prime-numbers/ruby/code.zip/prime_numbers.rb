require_relative "../../../../function-prime/ruby/response/src/function_prime"

=begin
  begin: 1..n
  end: 1..n, end > begin
=end

def primes(bg:nil, ed:)
  # TODO
end