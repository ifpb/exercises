<?php

function gtZero($products)
{
  // TODO
}

function subTotal($products)
{
  // TODO
}

function total($products)
{
  // TODO
}
