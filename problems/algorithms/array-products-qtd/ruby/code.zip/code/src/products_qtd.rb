class Products
    def Products.total(cart)
        #TODO
    end
end