import { total } from "./products.js";

// Cart Tool

const products = [
  ["Bicicleta", 1200.0],
  ["Capacete", 450.0]
];

// counting total cart
console.log(total(products));
console.log(1650.0);
