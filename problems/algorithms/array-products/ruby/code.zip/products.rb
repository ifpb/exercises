class Products
    def Products.total(carrinho)
      #TODO
    end
  end