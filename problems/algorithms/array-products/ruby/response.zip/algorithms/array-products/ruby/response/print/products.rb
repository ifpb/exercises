require_relative "../src/products"

puts Products.total([['Bicicleta', 1200.0], ['Capacete', 450.0]])
puts (1650.0)