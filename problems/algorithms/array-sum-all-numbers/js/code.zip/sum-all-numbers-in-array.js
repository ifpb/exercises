function sumIntegerInArray(array) {
  // TODO...
}

export { sumIntegerInArray };
