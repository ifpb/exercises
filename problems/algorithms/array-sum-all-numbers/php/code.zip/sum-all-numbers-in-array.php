<?php

function sumIntegerInArray($array)
{
  // TODO...
}
