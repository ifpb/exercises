class Numbers
    
    def Numbers.sum(numbers)
        #TODO
    end
    
end