function min(array) {
  // TODO
}

function max(array) {
  // TODO
}

function range(length, last, step) {
  // TODO
}

function zip(...arrays) {
  // TODO
}

function uniq(array) {
  // TODO
}

function sortNum(array) {
  // TODO
}

export { min, max, range, zip, uniq, sortNum };
