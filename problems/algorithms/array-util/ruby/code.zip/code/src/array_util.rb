class ArrayUtil

  def ArrayUtil.min(array)
    #TODO
  end

  def ArrayUtil.max(array)
    #TODO
  end

  def ArrayUtil.range(n)
    #TODO
  end

  def ArrayUtil.zip(*args)
    #TODO
  end

  def ArrayUtil.uniq(array)
    #TODO
  end

  def ArrayUtil.sortNum(array)
    #TODO
  end

end
