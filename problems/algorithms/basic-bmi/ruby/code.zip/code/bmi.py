# BMI = weight/height²

weight = 60
height = 1.65
result = ''

# TODO if
# Output:
#  BMI: 22.03856749311295
#  Result: Normal weight
