<?php

const size = 10;

// TODO h(10)
// h = 1/1 + 1/2 + ... + 1/n

// Output: h(10): 2.9289682539683
