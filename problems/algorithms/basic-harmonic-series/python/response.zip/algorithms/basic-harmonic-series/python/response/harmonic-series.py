
size = 10
sum = 0

for number in range(1, size):
  sum += 1 / number

print(f'h({size}): {sum}')
