#include <iostream>
#include <string>
using namespace std;

int main() 
{
  string name = "Alice";
  // TODO
  //  Hello, Alice!
  return 0;
}
