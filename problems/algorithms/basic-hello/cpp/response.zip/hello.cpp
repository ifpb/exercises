#include <iostream>
#include <string>
using namespace std;

int main() 
{
  string name = "Alice";
  cout << "Hello, " << name << "!";
  return 0;
}
