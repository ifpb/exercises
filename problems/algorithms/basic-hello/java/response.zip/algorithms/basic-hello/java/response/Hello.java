public class Hello {

  public static void main(String[] args) {
    String name = "Alice";
    System.out.println(String.format("Hello, %s!", name));
  }

}
