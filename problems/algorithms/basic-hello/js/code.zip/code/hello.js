name = "Alice";

// TODO Output:
//  Hello, Alice!
