name = "Alice";
console.log(`Hello, ${name}!`);
