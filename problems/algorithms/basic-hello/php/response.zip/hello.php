<?php

$name = 'Alice';
echo "Hello, ${name}!";
