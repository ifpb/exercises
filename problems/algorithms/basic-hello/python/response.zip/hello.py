
name = "Alice"
print(f'Hello, {name}!')
