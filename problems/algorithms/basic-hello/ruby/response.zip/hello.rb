
name = "Alice"
puts "Hello, #{name}!"
