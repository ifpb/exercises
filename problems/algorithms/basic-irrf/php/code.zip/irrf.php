<?php

const salary = 3500;

// TODO
// Output: IRRF: 170.2
