require_relative "../src/birthday_candy_candles"

# getting count of the highter candle number 
puts BirthdayCandyCandles.candle([3, 2, 1, 3])
puts 2

# getting count of the highter candle number
puts BirthdayCandyCandles.candle([18, 90, 90, 13, 90, 75, 90, 8, 90, 43])
puts 5
 