class BirthdayCandyCandles
  def BirthdayCandyCandles.candle(array)
    #TODO
  end
end
