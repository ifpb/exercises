function diffMonth(start, end) {
  // TODO
}

export { diffMonth };
