require 'date'

class DateDiff
    def DateDiff.compute(start, endDate)
       #TODO
    end
end