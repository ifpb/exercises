require_relative "../src/diff_timestamp"

puts DateDiff.compute(1483239600000, 1496762425846)