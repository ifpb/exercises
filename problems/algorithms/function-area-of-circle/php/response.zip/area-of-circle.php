<?php
 // A = πr²

function areaOfCircle($radius)
{
  return M_PI * $radius ** 2;
}
