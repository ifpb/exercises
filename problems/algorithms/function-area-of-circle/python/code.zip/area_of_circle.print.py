from area_of_circle import areaOfCircle

# Circle Tools

# Area of the circle of radius 10 is of 31.41592653589793
print(areaOfCircle(10))
print(314.1592653589793)

# Area of the circle of radius 1 is of 3.141592653589793
print(areaOfCircle(1))
print(3.141592653589793)