import math

def areaOfCircle(radius):
  # TODO
