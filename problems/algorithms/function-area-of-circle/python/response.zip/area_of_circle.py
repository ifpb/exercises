import math

def areaOfCircle(radius):
  return math.pi * radius ** 2
