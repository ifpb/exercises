class AreaOfCircle
    def AreaOfCircle.compute(r)
      # TODO
    end
  end