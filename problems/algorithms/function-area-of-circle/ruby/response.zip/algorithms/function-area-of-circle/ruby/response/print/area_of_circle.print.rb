require_relative "../src/area_of_circle"

# Area of Circle - Radius 2
puts AreaOfCircle.compute(2)
puts (12.56)

# Area of Circle - Radius 3
puts AreaOfCircle.compute(3)
puts (28.26)
