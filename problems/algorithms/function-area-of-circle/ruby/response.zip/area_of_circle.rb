class AreaOfCircle
    def AreaOfCircle.compute(r)
      return 3.14 * (r ** 2)
    end
  end