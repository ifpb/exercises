<?php

/**
 * $operator: '+', '-', '*', '/'
 */
function calc($operand1, $operand2, $operator)
{
  // TODO
}

function calcWithEval($operand1, $operand2, $operator)
{
  // TODO 
  // Tips echo eval('return 1+1;');
}
 