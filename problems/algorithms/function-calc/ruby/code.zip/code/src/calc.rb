class Calc
  def Calc.calc(a, b, operator)
    #TODO
  end
end
