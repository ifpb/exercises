require_relative "../src/calc"

puts Calc.calc(6, 2, '+')
puts 8

puts Calc.calc(6, 2, '-')
puts 4

puts Calc.calc(6, 2, '*')
puts 12

puts Calc.calc(6, 2, '/')
puts 3