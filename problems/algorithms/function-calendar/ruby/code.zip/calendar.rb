def calendar(start, count)
  # TODO
end