import { factorial } from "./factorial.js";

// Number Tools

// calculating factorial of 1
console.log(factorial(1));
console.log(1);

// calculating factorial of 2
console.log(factorial(2));
console.log(2);

// calculating factorial of 3
console.log(factorial(3));
console.log(6);

// calculating factorial of 4
console.log(factorial(4));
console.log(24);
