<?php

function factorial($number)
{
  // TODO
}
