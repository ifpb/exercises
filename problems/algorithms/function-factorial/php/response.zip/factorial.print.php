<?php

require __DIR__ . '/../src/factorial.php';

// Number Tools

// calculating factorial of 1
var_dump(factorial(1));
var_dump(1);

// calculating factorial of 2
var_dump(factorial(2));
var_dump(2);

// calculating factorial of 3
var_dump(factorial(3));
var_dump(6);

// calculating factorial of 4
var_dump(factorial(4));
var_dump(24);
