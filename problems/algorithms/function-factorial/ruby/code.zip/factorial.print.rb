require_relative "../src/factorial"

# Number Tools

# Factorial of 1
puts factorial(1)
puts 1

# Factorial of 2
puts factorial(2)
puts 2

# Factorial of 3
puts factorial(3)
puts 6

# Factorial of 4
puts factorial(4)
puts 24
 