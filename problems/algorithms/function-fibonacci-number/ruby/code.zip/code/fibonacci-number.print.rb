require_relative 'fibonacci-number.rb'

# Fibonacci series

# making the 0th number
puts fibonacci(0)
puts nil

# making the 1st numbers
puts fibonacci(1)
puts 0

# making the 2nd numbers
puts fibonacci(2)
puts 1

# making the 4th numbers
puts fibonacci(4)
puts 2

# making the 6th numbers
puts fibonacci(6)
puts 5
