def fibonacci(number)
  # TODO
end
