require_relative "../src/fibonacci_sequence"

#Fibonacci series

#making the first 0 numbers
puts(fibonacci(0));
puts('');

#making the first 1 numbers
puts(fibonacci(1));
puts('0');

#making the first 2 numbers
puts(fibonacci(2));
puts('0, 1');

#making the first 4 numbers
puts(fibonacci(4));
puts('0, 1, 1, 2');

#making the first 6 numbers
puts(fibonacci(6));
puts('0, 1, 1, 2, 3, 5');