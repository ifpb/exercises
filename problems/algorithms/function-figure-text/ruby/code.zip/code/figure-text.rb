
def half_square(size)
  # TODO
end

def triangle_text(size)
  # TODO
end

def half_diamond_text(size)
  # TODO
end

def diamond_text(size)  
  # TODO
end

def board_text(size) 
  # TODO
end