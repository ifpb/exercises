<?php

require __DIR__ . '/../src/prime-nth.php';

// Number Tools

// looking for the first 4 prime number
var_dump(nthPrime(4));
var_dump(7);

// looking for the first 6 prime number
var_dump(nthPrime(6));
var_dump(13);
