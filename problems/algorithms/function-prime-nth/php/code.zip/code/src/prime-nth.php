<?php

require __DIR__ . '/../../../prime/response/src/prime.php';

function nthPrime($nth)
{
  // TODO
}
