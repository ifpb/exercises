require_relative '../../../function-prime/ruby/prime.rb'

# begin: 1..n
# end: 1..n, end > begin

def nthPrime(nth)
  # TODO
end

