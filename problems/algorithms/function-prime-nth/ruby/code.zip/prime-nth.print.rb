require_relative 'prime-nth.rb'

# Number Tools

# looking for the first 4 prime number
puts nthPrime(4)
puts 7

# looking for the first 6 prime number
puts nthPrime(6)
puts 13
