function isPrime(number) {
  // TODO
}

export { isPrime };
