<?php

function isPrime($number)
{
  // TODO
}
