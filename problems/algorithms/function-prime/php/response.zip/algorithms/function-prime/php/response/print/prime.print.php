<?php

require __DIR__ . '/../src/prime.php';

// Number Tools

// checking if the number 2 is prime
var_dump(isPrime(2));
var_dump(true);

// checking if the number 3 is prime
var_dump(isPrime(3));
var_dump(true);

// checking if the number 4 is prime
var_dump(isPrime(4));
var_dump(false);

// checking if the number 5 is prime
var_dump(isPrime(5));
var_dump(true);

// checking if the number 6 is prime
var_dump(isPrime(6));
var_dump(false);

// checking if the number 7 is prime
var_dump(isPrime(7));
var_dump(true);
