require_relative "../src/function_prime"

# Number Tools

## checking if the number 2 is prime
p (isPrime(2));
p (true);

## checking if the number 3 is prime
p (isPrime(3));
p (true);

## checking if the number 4 is prime
p (isPrime(4));
p (false);

## checking if the number 5 is prime
p (isPrime(5));
p (true);

## checking if the number 6 is prime
p (isPrime(6));
p (false);

## checking if the number 7 is prime
p (isPrime(7));
p (true);
