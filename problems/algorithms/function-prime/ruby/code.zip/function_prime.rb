def isPrime(number)
  # TODO
end
  

