<?php

require __DIR__ . '/../src/sum.php';

// Number Tools

// adding 1 + 2
var_dump(sum(1, 2));
var_dump(3);

// adding 3 + 2
var_dump(sum(3, 2));
var_dump(5);
 