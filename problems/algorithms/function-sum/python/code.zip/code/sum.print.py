from sum import sum

# Number Tools

# adding 1 + 2
print(sum(1, 2))
print(3)

# adding 3 + 2
print(sum(3, 2))
print(5)
 