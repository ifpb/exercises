class Sum
  def Sum.compute(a, b)
    # TODO
  end
end
