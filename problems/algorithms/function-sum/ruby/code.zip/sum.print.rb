require_relative "../src/sum"

# Number Tools

# adding 1 + 2
puts Sum.compute(1, 2)
puts 3

# adding 3 + 2
puts Sum.compute(3, 2)
puts 5
 