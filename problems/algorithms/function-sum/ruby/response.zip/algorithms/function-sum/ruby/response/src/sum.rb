class Sum
  def Sum.compute(a, b)
    return a + b
  end
end
