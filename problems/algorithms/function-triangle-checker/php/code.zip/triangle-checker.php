<?php

function triangleChecker($a, $b, $c)
{
  // TODO
}
