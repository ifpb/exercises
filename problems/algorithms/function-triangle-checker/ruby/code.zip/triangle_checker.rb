class TriangleChecker
  def TriangleChecker.compute(a, b, c)
    # TODO
  end
end