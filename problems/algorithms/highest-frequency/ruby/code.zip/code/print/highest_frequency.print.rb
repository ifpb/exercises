require_relative "../src/highest_frequency"

# mirror sequence in a interval from 1 to 5
puts HighestFrequency.highest([1, 4, 4, 4, 5, 3])
puts 4

# mirror sequence in a interval from 1 to 5
puts MirrorSequence.highest([1, 2, 3, 4, 5, 4, 3, 2, 1, 3, 4])
puts 3
 