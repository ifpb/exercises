def random(min = 1, max)
  # TODO
end

def randArray(array) 
  # TODO
end