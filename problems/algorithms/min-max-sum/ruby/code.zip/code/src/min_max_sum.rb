def minMaxSum(array)
  # TODO
end