require_relative "../src/mirror_sequence"

# mirror sequence in a interval from 1 to 5
puts MirrorSequence.mirror(1, 5)
puts 1234554321

# mirror sequence in a interval from 1 to 5
puts MirrorSequence.mirror(10, 13)
puts 1011121331211101
 