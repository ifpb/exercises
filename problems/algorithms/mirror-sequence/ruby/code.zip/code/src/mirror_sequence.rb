class MirrorSequence
    def MirrorSequence.mirror(a,b)  
        #TODO
   end
end