function firstTeam() {
  // TODO
}

function showStading() {
  // TODO
}

export { firstTeam, showStading };
