class BrazilianChampionship
  #TODO
end