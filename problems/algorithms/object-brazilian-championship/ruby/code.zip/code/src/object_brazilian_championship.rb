class BrazilianChampionship
  #TODO
end