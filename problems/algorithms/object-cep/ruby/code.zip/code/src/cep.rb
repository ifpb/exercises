class Cep
  def Cep.get_info(cep)
    # TODO
  end
end