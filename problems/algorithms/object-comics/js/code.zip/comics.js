function namesByComics(characters, comics) {
  // TODO
}

function topWeightNames(characters, comics) {
  // TODO
}

function weight(characters, comics) {
  // TODO
}

export { namesByComics, topWeightNames, weight };
