<?php

class Character
{
  // TODO
}
