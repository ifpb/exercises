<?php
require 'character.php';

class Comic
{
  // TODO
}
