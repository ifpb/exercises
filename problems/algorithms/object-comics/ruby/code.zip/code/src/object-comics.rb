class Comics
 #TODO
end