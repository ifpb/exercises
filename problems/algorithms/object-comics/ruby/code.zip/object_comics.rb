class Comics
 #TODO
end