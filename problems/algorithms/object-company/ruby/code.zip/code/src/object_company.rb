class Company
  #TODO
end