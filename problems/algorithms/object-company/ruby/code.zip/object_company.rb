class Company
  #TODO
end