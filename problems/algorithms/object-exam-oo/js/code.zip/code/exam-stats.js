class ExamStats {
  // TODO
}

export { ExamStats };
