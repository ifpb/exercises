class ExamCheck
  def initialize(answer, weight)
    #TODO
  end
  def grade(student)
    #TODO
  end
end
