class ExamStats
  def initialize(students)
    #TODO
  end
    def avg() 
      #TODO
    end

  def min(count = 1) 
    #TODO
  end

  def max(count = 1) 
    #TODO
  end

  def lt(limit) 
    #TODO
  end

  def gt(limit) 
    #TODO
  end
end
