<?php

class Exam
{
  // TODO
}
