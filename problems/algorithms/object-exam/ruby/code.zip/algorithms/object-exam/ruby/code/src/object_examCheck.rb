class ExamCheck
  #TODO
end
