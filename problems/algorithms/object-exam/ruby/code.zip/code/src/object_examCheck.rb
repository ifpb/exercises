class ExamCheck
  #TODO
end
