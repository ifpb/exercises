class ExamStats
  #TODO
end