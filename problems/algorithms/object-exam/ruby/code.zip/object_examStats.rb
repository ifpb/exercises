class ExamStats
  #TODO
end