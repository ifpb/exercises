<?php

class Product
{
  // TODO
}
