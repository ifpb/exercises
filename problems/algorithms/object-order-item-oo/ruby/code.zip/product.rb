class Product
  # TODO
end
