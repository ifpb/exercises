class Products
  def Products.gt_zero(products)
    # TODO  
  end
  def Products.sub_total(products)
    # TODO
  end
  def Products.total(products)
    # TODO
  end
end