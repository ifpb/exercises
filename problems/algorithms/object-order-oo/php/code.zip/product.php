<?php

class Product
{

  public function __constructor($id, $name, $price = null)
  {
    // TODO
  }
}
