<?php

class Order
{
  // TODO
}
