class Products
  def Products.compute(products)
    #TODO
  end
end