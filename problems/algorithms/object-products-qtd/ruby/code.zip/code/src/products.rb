class Product
    def Product.total(products) 
      #TODO
    end
  end 