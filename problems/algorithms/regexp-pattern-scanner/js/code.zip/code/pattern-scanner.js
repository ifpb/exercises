function scanDate(text) {
  // TODO
}

function scanCep(text) {
  // TODO
}

export { scanDate, scanCep };
