class PatternValidator

  def PatternValidator.validateCpf()
    #TODO
  end

  def PatternValidator.validateCep()
    #TODO
  end

end
