require_relative "../src/sock_merchant"

# Getting count by pairs of socks from the same type
puts SockMerchant.count_pair_of_socks([10, 20, 20, 10, 10, 30, 50, 10, 20])
puts (3)

# Getting count by pairs of socks from the same type
puts SockMerchant.count_pair_of_socks([1, 2, 1, 2, 1, 3, 2])
puts (2)

