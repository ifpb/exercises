function rot(message, number) {
  // TODO
}

export { rot };
