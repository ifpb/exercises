class Cipher
  def Cipher.complent(rotate)
    # TODO
  end
  
  def Cipher.rot(message, number = 13)
    # TODO
  end
end