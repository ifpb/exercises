class Citation
    def Citation.longCitation(name)
        #TODO
    end

    def compactCitation(name)
        #TODO
    end
end