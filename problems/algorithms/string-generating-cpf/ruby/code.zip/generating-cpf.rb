def cpf_check_digit(cpf)
  # TODO
end
