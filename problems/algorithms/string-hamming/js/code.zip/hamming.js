function hamming(dna1, dna2) {
  // TODO
}

export { hamming };
