def hamming(dna1, dna2)
  #TODO
end


