function ip2decimal() {
  // TODO
}

function decimal2ip() {
  // TODO
}

export { ip2decimal, decimal2ip };
