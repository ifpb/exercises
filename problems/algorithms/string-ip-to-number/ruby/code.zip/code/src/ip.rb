def ip2decimal(ip)
  # TODO
end

def decimal2ip(decimal)
  # TODO
end