function createList(number) {
  // TODO
}

export { createList };
