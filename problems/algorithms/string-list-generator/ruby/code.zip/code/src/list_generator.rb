class ListGenerator
  def ListGenerator.create_list(number, text = :Text)
    # TODO
  end
end