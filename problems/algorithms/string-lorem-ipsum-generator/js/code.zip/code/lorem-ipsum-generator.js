function word(number) {
  // TODO
}

function paragraph(number) {
  // TODO
}

export { word, paragraph };
