class StringLoremIpsumGenerator

  def StringLoremIpsumGenerator.word(number)
    # TODO
  end
  
  def StringLoremIpsumGenerator.paragraph(number) 
    # TODO
    end
end