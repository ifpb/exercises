function toRna(dna) {
  // TODO
}

export { toRna };
