class DNA
  def DNA.to_rna(dna)
    # TODO
  end
end
