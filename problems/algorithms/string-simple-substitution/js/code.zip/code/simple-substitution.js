function substitution(message, plaintext, ciphertext) {
  // TODO
}

export { substitution };
