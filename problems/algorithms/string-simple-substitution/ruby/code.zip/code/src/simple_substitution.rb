class Text
    def Text.substitution(message, plaintext, ciphertext)
        #TODO
    end
end