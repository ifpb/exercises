function createTable(rows, cols, text) {
  // TODO
}

function createTableHTML(rows, cols, text) {
  // TODO
}

export { createTable, createTableHTML };
