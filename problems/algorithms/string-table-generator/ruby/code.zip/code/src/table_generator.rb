class TableGenerator
  def TableGenerator.create_table(rows, cols, text = '')
    #TODO
  end

  def TableGenerator.create_table_HTML(rows, cols, text = '')
    #TODO
  end
end
