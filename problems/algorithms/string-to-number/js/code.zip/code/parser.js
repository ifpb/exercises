function str2hex() {
  // TODO
}

function hex2str() {
  // TODO
}

function str2bin() {
  // TODO
}

function bin2str() {
  // TODO
}

function str2dec() {
  // TODO
}

function dec2str() {
  // TODO
}

export { str2hex, hex2str, str2bin, bin2str, str2dec, dec2str };
