# text: string
# action: lowercase, uppercase, camelcase, snakecase, reverse,
#         countchar, countword, countline
#
def formatter(text, action)
  #TODO
end

