function checkingDigitCpf(cpf) {
  // TODO
}

export { checkingDigitCpf };
