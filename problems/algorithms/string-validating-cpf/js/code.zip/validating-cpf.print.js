import { checkingDigitCpf } from "./validating-cpf.js";

// Checking Digit CPF

// the check digit of 123456789 is 09
console.log(checkingDigitCpf("12345678909"));
console.log(true);
