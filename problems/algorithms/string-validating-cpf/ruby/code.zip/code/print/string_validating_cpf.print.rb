require_relative "../src/string_validating_cpf"

# Checking Digit CPF

# the check digit of 123456789 is 09
p (checkingDigitCpf('12345678909'));
p (true);

