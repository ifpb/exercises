def checkingDigitCpf(cpf)
  # TODO
end
  

