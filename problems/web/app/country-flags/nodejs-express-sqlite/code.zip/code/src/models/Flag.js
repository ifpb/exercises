const { conn } = require('../db');

async function create(data) {
  // TODO
}

async function readAll() {
  // TODO
}

async function readById(id) {
  // TODO
}

module.exports = { create, readAll, readById };
