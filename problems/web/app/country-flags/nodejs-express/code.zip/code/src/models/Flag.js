let key = 1;
const flags = [];

function create(values) {
  // TODO
}

function readAll() {
  return flags;
}

module.exports = { create, readAll };
