const express = require('express');
const formatter = require('./util/text.js');
const calculator = require('./util/number.js');

// TODO HTTP Response
